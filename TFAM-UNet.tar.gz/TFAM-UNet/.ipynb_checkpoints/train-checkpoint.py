import torch
from torch import nn
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import DataLoader, Subset
import numpy as np
import os
import sys
import warnings
import cv2
from sklearn.model_selection import KFold   # 新增：用于k折划分

warnings.filterwarnings("ignore")

os.environ["CUDA_VISIBLE_DEVICES"] = "0"


# ==================== 自定义数据集 ====================
class BrainTumorDataset(torch.utils.data.Dataset):
    def __init__(self, data_dir, train=True, test=False, transform=None):
        self.data_dir = data_dir
        self.train = train
        self.test = test
        self.transform = transform

        if train:
            self.data_path = os.path.join(data_dir, 'data_train.npy')
            self.mask_path = os.path.join(data_dir, 'mask_train.npy')
        elif test:
            self.data_path = os.path.join(data_dir, 'data_test.npy')
            self.mask_path = os.path.join(data_dir, 'mask_test.npy')
        else:
            self.data_path = os.path.join(data_dir, 'data_val.npy')
            self.mask_path = os.path.join(data_dir, 'mask_val.npy')

        self.data = np.load(self.data_path)
        self.masks = np.load(self.mask_path)

        print(f"Loaded {len(self.data)} samples from {self.data_path}")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        image = self.data[idx].astype(np.float32)
        mask = self.masks[idx].astype(np.float32)

        if image.ndim == 2:
            image = image[np.newaxis, :, :]
        elif image.ndim == 3:
            image = image.transpose(2, 0, 1)
            if image.shape[0] != 1:
                image = image[0:1, :, :]
        else:
            raise ValueError(f"Unexpected image shape: {image.shape}")

        if mask.ndim == 2:
            mask = mask[np.newaxis, :, :]
        elif mask.ndim == 3:
            mask = mask.transpose(2, 0, 1)
            if mask.shape[0] != 1:
                mask = mask[0:1, :, :]
        else:
            raise ValueError(f"Unexpected mask shape: {mask.shape}")

        mask = mask / 255.0

        image = torch.from_numpy(image.copy())
        mask = torch.from_numpy(mask.copy())

        return image, mask


# ==================== 模型适配器 ====================
class UltraLight_VM_UNet_Adapter(nn.Module):
    def __init__(self, num_classes=1, input_channels=1, **kwargs):
        super(UltraLight_VM_UNet_Adapter, self).__init__()
        from models.UltraLight_VM_UNet import UltraLight_VM_UNet
        self.model = UltraLight_VM_UNet(
            num_classes=num_classes,
            input_channels=input_channels
        )
        self.kwargs = kwargs

    def forward(self, x):
        return self.model(x)


# ==================== 主训练函数（已改为k折交叉验证）====================
def main(config=None, k_folds=5):
    if config is None:
        config = type('Config', (), {})()
        config.work_dir = './results'
        config.data_path = './'
        config.batch_size = 8
        config.epochs = 100
        config.num_workers = 4
        config.seed = 42
        config.model_config = {
            'num_classes': 1,
            'input_channels': 1,
            'c_list': [16, 32, 64, 128, 256],
            'split_att': 'fc',
            'bridge': True,
        }
        config.criterion = torch.nn.BCEWithLogitsLoss()
        config.opt = 'Adam'
        config.lr = 1e-4
        config.weight_decay = 1e-5
        config.sch = 'CosineAnnealingLR'
        config.T_max = 50
        config.eta_min = 1e-6
        config.print_interval = 20
        config.val_interval = 1
        config.save_interval = 10

    elif hasattr(config, '__call__'):
        config = config()

    print('#----------Creating logger----------#')
    sys.path.append(config.work_dir + '/')

    from datetime import datetime
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_work_dir = f'./results/work_dir_brats_{timestamp}'
    os.makedirs(base_work_dir, exist_ok=True)
    
    config.work_dir = base_work_dir
    os.makedirs(os.path.join(config.work_dir, 'outputs'), exist_ok=True)

    from utils import get_logger, log_config_info, set_seed, get_optimizer, get_scheduler

    print('#----------GPU init----------#')
    set_seed(config.seed)
    gpu_ids = [0]
    torch.cuda.empty_cache()

    print('#----------Preparing dataset----------#')
    data_path = config.data_path
    print(f"数据路径: {data_path}")

    required_files = ['data_train.npy', 'mask_train.npy',
                      'data_val.npy', 'mask_val.npy',
                      'data_test.npy', 'mask_test.npy']
    missing_files = [f for f in required_files if not os.path.exists(os.path.join(data_path, f))]

    if missing_files:
        print(f"警告: 缺少文件 {missing_files}，将使用随机数据")
        class SimpleDataset(torch.utils.data.Dataset):
            def __init__(self, n_samples=100):
                self.n_samples = n_samples
            def __len__(self):
                return self.n_samples
            def __getitem__(self, idx):
                img = torch.randn(1, 256, 256)
                mask = torch.randn(1, 256, 256)
                return img, mask

        train_dataset = SimpleDataset(671)
        val_dataset = SimpleDataset(144)
        test_dataset = SimpleDataset(144)
    else:
        train_dataset = BrainTumorDataset(data_path, train=True)
        val_dataset = BrainTumorDataset(data_path, train=False)
        test_dataset = BrainTumorDataset(data_path, test=True)

    # 合并 train + val，作为交叉验证的全量数据
    full_train_dataset = torch.utils.data.ConcatDataset([train_dataset, val_dataset])
    full_indices = np.arange(len(full_train_dataset))
    print(f"交叉验证全量数据: {len(full_train_dataset)} 样本 (训练{len(train_dataset)} + 验证{len(val_dataset)})")

    # 测试集保持不变
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False,
                             pin_memory=True, num_workers=config.num_workers, drop_last=True)

    # K折划分
    kfold = KFold(n_splits=k_folds, shuffle=True, random_state=config.seed)

    fold_test_losses = []
    fold_best_val_losses = []

    for fold, (train_idx, val_idx) in enumerate(kfold.split(full_indices), start=1):
        print(f'\n========== Fold {fold}/{k_folds} ==========')

        # 为当前fold创建工作目录
        fold_work_dir = os.path.join(base_work_dir, f'fold_{fold}')
        log_dir = os.path.join(fold_work_dir, 'log')
        checkpoint_dir = os.path.join(fold_work_dir, 'checkpoints')
        for d in [log_dir, checkpoint_dir]:
            os.makedirs(d, exist_ok=True)

        global logger
        logger = get_logger('train', log_dir)
        log_config_info(config, logger)
        logger.info(f'Fold {fold} started')

        # 构建DataLoader
        train_subset = Subset(full_train_dataset, train_idx)
        val_subset = Subset(full_train_dataset, val_idx)
        train_loader = DataLoader(train_subset, batch_size=config.batch_size, shuffle=True,
                                  pin_memory=True, num_workers=config.num_workers)
        val_loader = DataLoader(val_subset, batch_size=1, shuffle=False,
                                pin_memory=True, num_workers=config.num_workers, drop_last=True)

        # 模型初始化
        print('#----------Preparing Model----------#')
        from models.UltraLight_VM_UNet import UltraLight_VM_UNet
        model_cfg = config.model_config
        try:
            model = UltraLight_VM_UNet_Adapter(
                num_classes=model_cfg['num_classes'],
                input_channels=model_cfg['input_channels'],
                c_list=model_cfg.get('c_list', [16, 32, 64, 128, 256]),
                split_att=model_cfg.get('split_att', 'fc'),
                bridge=model_cfg.get('bridge', True)
            )
        except Exception as e:
            print(f"适配器失败: {e}")
            try:
                model = UltraLight_VM_UNet(
                    num_classes=model_cfg['num_classes'],
                    input_channels=model_cfg['input_channels']
                )
            except Exception as e2:
                print(f"直接创建失败: {e2}")
                model = UltraLight_VM_UNet()

        model = torch.nn.DataParallel(model.cuda(), device_ids=gpu_ids, output_device=gpu_ids[0])

        # 损失、优化器、调度器
        criterion = config.criterion
        optimizer = get_optimizer(config, model)
        scheduler = get_scheduler(config, optimizer)
        scaler = GradScaler()

        # 训练参数
        min_loss = 999
        start_epoch = 1
        min_epoch = 1

        # 训练循环
        from engine import train_one_epoch, val_one_epoch, test_one_epoch

        for epoch in range(start_epoch, config.epochs + 1):
            torch.cuda.empty_cache()
            train_one_epoch(train_loader, model, criterion, optimizer, scheduler,
                            epoch, logger, config, scaler=scaler)
            loss = val_one_epoch(val_loader, model, criterion, epoch, logger, config)

            if loss < min_loss:
                torch.save(model.module.state_dict(), os.path.join(checkpoint_dir, 'best.pth'))
                min_loss = loss
                min_epoch = epoch

            torch.save({
                'epoch': epoch,
                'min_loss': min_loss,
                'min_epoch': min_epoch,
                'loss': loss,
                'model_state_dict': model.module.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
            }, os.path.join(checkpoint_dir, 'latest.pth'))

            print(f"Fold {fold}, Epoch {epoch}/{config.epochs}, Val Loss: {loss:.4f}, Best: {min_loss:.4f} at {min_epoch}")

        fold_best_val_losses.append(min_loss)
        logger.info(f'Fold {fold} finished. Best val loss: {min_loss:.4f}')

        # 在测试集上评估当前fold最佳模型
        best_weight_path = os.path.join(checkpoint_dir, 'best.pth')
        if os.path.exists(best_weight_path):
            best_weight = torch.load(best_weight_path, map_location=torch.device('cpu'))
            model.module.load_state_dict(best_weight)
            test_loss = test_one_epoch(test_loader, model, criterion, logger, config)
            fold_test_losses.append(test_loss)
            print(f"Fold {fold} Test Loss: {test_loss:.4f}")
        else:
            print("警告：best.pth 未找到，跳过测试评估")
            fold_test_losses.append(None)

    # 输出最终汇总
    print("\n" + "=" * 50)
    print(f"{k_folds}-折交叉验证完成")
    print(f"各折最佳验证损失: {[f'{l:.4f}' for l in fold_best_val_losses]}")
    if all(v is not None for v in fold_test_losses):
        print(f"各折测试损失:      {[f'{l:.4f}' for l in fold_test_losses]}")
        print(f"平均测试损失:      {np.mean(fold_test_losses):.4f} ± {np.std(fold_test_losses):.4f}")
    print("=" * 50)


if __name__ == '__main__':
    print("检查数据文件...")
    base_dir = '.'
    npy_files = [f for f in os.listdir(base_dir) if f.endswith('.npy')]
    print(f"当前目录下的npy文件: {npy_files}")

    if not npy_files:
        print("未找到npy文件，请确保在正确的目录运行")
        print("当前目录:", os.getcwd())
        for root, dirs, files in os.walk('.'):
            for file in files:
                if file.endswith('.npy'):
                    print(f"找到: {os.path.join(root, file)}")

    try:
        from configs.config_setting import setting_config
        if hasattr(setting_config, '__call__'):
            config = setting_config()
        else:
            config = setting_config

        if not hasattr(config, 'model_config'):
            config.model_config = {'num_classes': 1, 'input_channels': 1}
        config.model_config['input_channels'] = 1
        if not hasattr(config, 'data_path') or not config.data_path:
            config.data_path = './'
    except Exception as e:
        print(f"配置处理错误: {e}")
        config = None

    # 默认执行折交叉验证，可根据需要修改
    # main(config, k_folds=20)
    main(config, k_folds=3)
